for question 4,5,6 insert the ORL/Yale datasets folder inside the "data" folder present in Q 4,5,6 respectively 
